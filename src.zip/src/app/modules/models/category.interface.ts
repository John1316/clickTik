export interface ICategory{

}
