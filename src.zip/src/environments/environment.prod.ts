export const environment = {
  production: true,
  apiUrl:'https://dummyjson.com/',
  titleUrl: 'Click tik | '
};
